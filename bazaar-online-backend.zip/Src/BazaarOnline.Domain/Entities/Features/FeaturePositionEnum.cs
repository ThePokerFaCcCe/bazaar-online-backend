﻿namespace BazaarOnline.Domain.Entities.Features;

public enum FeaturePositionEnum
{
    Top = 1,
    Middle = 2,
    Bottom = 3,
    Other = 4,
}