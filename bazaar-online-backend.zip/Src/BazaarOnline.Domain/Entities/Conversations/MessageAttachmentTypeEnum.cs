﻿namespace BazaarOnline.Domain.Entities.Conversations
{
    public enum MessageAttachmentTypeEnum
    {
        NoAttachment = 0,
        Picture = 1,
        Voice = 2,
        Location = 3,
    }
}