﻿namespace BazaarOnline.Domain.Entities.UploadCenter;

public enum FileCenterTypeEnum
{
    AdvertisementPicture = 1,
    ChatPicture = 2,
    ChatVoice = 3,
}