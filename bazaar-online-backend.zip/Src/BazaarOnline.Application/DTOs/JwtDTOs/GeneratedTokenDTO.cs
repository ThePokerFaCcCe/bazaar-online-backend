namespace BazaarOnline.Application.DTOs.JwtDTOs
{
    public class GeneratedTokenDTO
    {
        public string Token { get; set; }
        public DateTime ExpireDate { get; set; }
    }
}
