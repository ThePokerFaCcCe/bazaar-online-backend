﻿namespace BazaarOnline.Application.DTOs.UserDTOs
{
    public class CreateUserByEmailDTO
    {
        public string Email { get; set; }
    }
}
