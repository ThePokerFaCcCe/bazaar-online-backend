﻿namespace BazaarOnline.Application.DTOs.UserDTOs;

public class CreateUserByPhoneNumberDTO
{
    public string PhoneNumber { get; set; }
}