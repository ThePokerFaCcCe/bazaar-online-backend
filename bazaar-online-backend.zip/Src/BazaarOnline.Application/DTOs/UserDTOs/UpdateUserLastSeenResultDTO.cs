﻿namespace BazaarOnline.Application.DTOs.UserDTOs;

public class UpdateUserLastSeenResultDTO
{
    public DateTime LastSeen { get; set; }
    
    public string UserId { get; set; }
}   