﻿namespace BazaarOnline.Application.DTOs.ConversationDTOs;

public class SeenConversationDTO
{
    public Guid ConversationId { get; set; } = Guid.Empty;
}