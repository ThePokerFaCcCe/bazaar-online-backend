﻿namespace BazaarOnline.Application.ViewModels.Advertisements;

public class AdvertisementLocationDetailViewModel
{
    public double? Longitude { get; set; }

    public double? Latitude { get; set; }

    public bool ShowExactCoordinates { get; set; }
}