﻿namespace BazaarOnline.Application.ViewModels.Advertisements;

public class AdvertisementProvinceDetailViewModel
{
    public int Id { get; set; } = 0;

    public string Name { get; set; } = string.Empty;
}