﻿namespace BazaarOnline.Application.ViewModels.Advertisements;

public class AdvertisementCategoryDetailViewModel
{
    public int Id { get; set; }

    public string Title { get; set; }
}