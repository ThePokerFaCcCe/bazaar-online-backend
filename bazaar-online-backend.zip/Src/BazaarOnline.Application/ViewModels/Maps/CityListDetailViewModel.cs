﻿namespace BazaarOnline.Application.ViewModels.Maps
{
    public class CityListDetailViewModel
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public int ProvinceId { get; set; }
    }
}