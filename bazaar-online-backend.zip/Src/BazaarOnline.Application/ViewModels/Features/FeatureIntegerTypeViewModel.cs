﻿namespace BazaarOnline.Application.ViewModels.Features;

public class FeatureIntegerTypeViewModel
{
    public long Minimum { get; set; }

    public long Maximum { get; set; }

    public string Placeholder { get; set; }
}