﻿namespace BazaarOnline.Application.ViewModels.Conversations;

public class ConversationUserIdViewModel
{
    public string UserId { get; set; }
    public Guid ConversationId { get; set; }
}